#include <iostream>
#include <stack>
#include <vector>
#include <iomanip>

using namespace std;

struct Quadruple
{
    string op, arg1, arg2, result;
};

struct Triple
{
    string op, arg1, arg2;
};

bool isOperator(char ch)
{
    return ch=='+' || ch=='-' ||
           ch=='*' || ch=='/';
}

int main()
{
    string postfix;

    cout << "Enter Postfix Expression: ";
    cin >> postfix;

    stack<string> st;

    vector<Quadruple> quad;
    vector<Triple> triple;

    int tempCount = 1;

    for(char ch : postfix)
    {
        if(!isOperator(ch))
        {
            st.push(string(1,ch));
        }
        else
        {
            string op2 = st.top();
            st.pop();

            string op1 = st.top();
            st.pop();

            string temp = "t" + to_string(tempCount++);

            quad.push_back({string(1,ch),op1,op2,temp});

            triple.push_back({string(1,ch),op1,op2});

            st.push(temp);
        }
    }

    cout << "\nQUADRUPLES\n";

    cout << left
         << setw(10) << "Op"
         << setw(10) << "Arg1"
         << setw(10) << "Arg2"
         << setw(10) << "Result" << endl;

    for(auto q : quad)
    {
        cout << left
             << setw(10) << q.op
             << setw(10) << q.arg1
             << setw(10) << q.arg2
             << setw(10) << q.result << endl;
    }

    cout << "\nTRIPLES\n";

    cout << left
         << setw(10) << "Index"
         << setw(10) << "Op"
         << setw(10) << "Arg1"
         << setw(10) << "Arg2" << endl;

    for(int i=0;i<triple.size();i++)
    {
        cout << left
             << setw(10) << i
             << setw(10) << triple[i].op
             << setw(10) << triple[i].arg1
             << setw(10) << triple[i].arg2
             << endl;
    }

    return 0;
}