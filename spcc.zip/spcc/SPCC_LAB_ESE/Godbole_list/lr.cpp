#include <iostream>
#include <stack>
#include <map>
using namespace std;

int main() {

    // Grammar:
    // E -> E+E | id
    //
    // Input example:
    // id+id
    //
    // This is a simple hardcoded LR(1) parser simulation.

    map<pair<int,string>, string> action;
    map<pair<int,string>, int> goTo;

    // ACTION TABLE
    action[{0,"id"}] = "S2";

    action[{1,"+"}] = "S3";
    action[{1,"$"}] = "ACC";

    action[{2,"+"}] = "R2";
    action[{2,"$"}] = "R2";

    action[{3,"id"}] = "S2";

    action[{4,"+"}] = "R1";
    action[{4,"$"}] = "R1";

    // GOTO TABLE
    goTo[{0,"E"}] = 1;
    goTo[{3,"E"}] = 4;

    string input;
    cout << "Enter input string: ";
    cin >> input;

    input += "$";

    stack<int> st;
    st.push(0);

    int i = 0;

    while (true) {

        int state = st.top();

        string symbol;

        // Read id token
        if (input.substr(i,2) == "id")
            symbol = "id";
        else
            symbol = string(1,input[i]);

        string act = action[{state, symbol}];

        if (act == "") {
            cout << "Rejected\n";
            break;
        }

        // SHIFT
        if (act[0] == 'S') {

            int nextState = act[1] - '0';

            st.push(nextState);

            if (symbol == "id")
                i += 2;
            else
                i++;

        }

        // REDUCE
        else if (act[0] == 'R') {

            int rule = act[1] - '0';

            // R1 : E -> E+E
            if (rule == 1) {

                st.pop();
                st.pop();
                st.pop();

                int topState = st.top();

                st.push(goTo[{topState,"E"}]);

            }

            // R2 : E -> id
            else if (rule == 2) {

                st.pop();

                int topState = st.top();

                st.push(goTo[{topState,"E"}]);

            }

        }

        // ACCEPT
        else if (act == "ACC") {
            cout << "Accepted\n";
            break;
        }
    }

    return 0;
}