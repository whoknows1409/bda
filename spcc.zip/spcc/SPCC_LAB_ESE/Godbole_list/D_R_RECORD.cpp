#include <iostream>
#include <iomanip>
#include <sstream>
#include <vector>

using namespace std;

struct Symbol
{
    string name;
    int value;
};

int main()
{
    int n;

    cout << "Enter Number of Lines: ";
    cin >> n;

    cin.ignore();

    vector<string> program(n);

    cout << "\nEnter ASM Program:\n";

    for(int i=0;i<n;i++)
    {
        getline(cin,program[i]);
    }

    vector<string> extdef;
    vector<string> extref;

    vector<Symbol> localTable;

    int locctr = 0;

    /////////////////////////////////////////////////////////
    // PROCESS PROGRAM
    /////////////////////////////////////////////////////////

    for(int i=0;i<n;i++)
    {
        string line = program[i];

        /////////////////////////////////////////////////////
        // START
        /////////////////////////////////////////////////////

        if(line.find("START") != string::npos)
        {
            locctr = 0;
        }

        /////////////////////////////////////////////////////
        // EXTDEF
        /////////////////////////////////////////////////////

        else if(line.find("EXTDEF") != string::npos)
        {
            string temp =
            line.substr(line.find("EXTDEF")+7);

            stringstream ss(temp);

            string symbol;

            while(getline(ss,symbol,','))
            {
                // Remove spaces
                while(symbol[0]==' ')
                    symbol.erase(0,1);

                extdef.push_back(symbol);
            }
        }

        /////////////////////////////////////////////////////
        // EXTREF
        /////////////////////////////////////////////////////

        else if(line.find("EXTREF") != string::npos)
        {
            string temp =
            line.substr(line.find("EXTREF")+7);

            stringstream ss(temp);

            string symbol;

            while(getline(ss,symbol,','))
            {
                while(symbol[0]==' ')
                    symbol.erase(0,1);

                extref.push_back(symbol);
            }
        }

        /////////////////////////////////////////////////////
        // LABEL DETECTION
        /////////////////////////////////////////////////////

        else
        {
            stringstream ss(line);

            string firstWord;

            ss >> firstWord;

            // If first word is not opcode
            if(firstWord!="ADD" &&
               firstWord!="SUB" &&
               firstWord!="MUL" &&
               firstWord!="DIV" &&
               firstWord!="END")
            {
                localTable.push_back(
                {
                    firstWord,
                    locctr
                });
            }

            // Every instruction = 3 bytes
            locctr += 3;
        }
    }

    /////////////////////////////////////////////////////////
    // PRINT D RECORD
    /////////////////////////////////////////////////////////

    cout << "\nD RECORD\n";

    cout << "D^";

    for(int i=0;i<extdef.size();i++)
    {
        for(auto s : localTable)
        {
            if(s.name == extdef[i])
            {
                cout << s.name
                     << "^"
                     << setw(6)
                     << setfill('0')
                     << s.value
                     << "^";
            }
        }
    }

    /////////////////////////////////////////////////////////
    // PRINT R RECORD
    /////////////////////////////////////////////////////////

    cout << "\n\nR RECORD\n";

    cout << "R^";

    for(auto x : extref)
    {
        cout << x << "^";
    }

    /////////////////////////////////////////////////////////
    // PRINT LOCAL SYMBOL TABLE
    /////////////////////////////////////////////////////////

    cout << "\n\nLOCAL SYMBOL TABLE\n\n";

    cout << left
         << setw(15) << "Symbol Name"
         << setw(10) << "Value"
         << endl;

    for(auto x : localTable)
    {
        cout << left
             << setw(15) << x.name
             << setw(10) << x.value
             << endl;
    }

    return 0;
}

/*
PG1 START 0000
EXTDEF A, B
EXTREF C , D
ADD ABC
A SUB PQR
ADD ABC1
B MUL ABC
END
*/