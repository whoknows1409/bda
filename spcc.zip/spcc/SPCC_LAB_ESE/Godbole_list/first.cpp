#include <iostream>
#include <cstring>
using namespace std;

char production[10][10];
char first[10];
int n;

void findFirst(char c, int q1, int q2) {
    int j;

    // If terminal
    if (!(isupper(c))) {
        first[q1++] = c;
    }

    for (j = 0; j < n; j++) {
        // Production starts with c
        if (production[j][0] == c) {

            // If epsilon
            if (production[j][2] == '#') {
                first[q1++] = '#';
            }

            // If terminal after =
            else if (!isupper(production[j][2])) {
                first[q1++] = production[j][2];
            }

            // If non-terminal
            else {
                findFirst(production[j][2], q1, q2);
            }
        }
    }
}

int main() {
    int i, j;
    char c;

    cout << "Enter number of productions: ";
    cin >> n;

    cout << "Enter productions (Example: A=a):\n";

    for (i = 0; i < n; i++) {
        cin >> production[i];
    }

    cout << "\nFIRST Sets:\n";

    for (i = 0; i < n; i++) {

        c = production[i][0];

        cout << "FIRST(" << c << ") = { ";

        findFirst(c, 0, 0);

        for (j = 0; first[j] != '\0'; j++) {
            cout << first[j] << " ";
        }

        cout << "}\n";

        memset(first, 0, sizeof(first));
    }

    return 0;
}