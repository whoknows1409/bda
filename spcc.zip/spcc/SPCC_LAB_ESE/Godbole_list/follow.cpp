#include <iostream>
#include <cstring>
using namespace std;

char production[10][10];
char follow[10];
int n, m = 0;

void findFollow(char c);

void first(char c) {
    int i;

    if (!isupper(c)) {
        follow[m++] = c;
        return;
    }

    for (i = 0; i < n; i++) {

        if (production[i][0] == c) {

            if (production[i][2] == '#') {
                continue;
            }

            else if (!isupper(production[i][2])) {
                follow[m++] = production[i][2];
            }

            else {
                first(production[i][2]);
            }
        }
    }
}

void findFollow(char c) {
    int i, j;

    // Start symbol
    if (production[0][0] == c) {
        follow[m++] = '$';
    }

    for (i = 0; i < n; i++) {

        for (j = 2; production[i][j] != '\0'; j++) {

            if (production[i][j] == c) {

                // Next symbol exists
                if (production[i][j + 1] != '\0') {
                    first(production[i][j + 1]);
                }

                // End of production
                if (production[i][j + 1] == '\0' &&
                    c != production[i][0]) {

                    findFollow(production[i][0]);
                }
            }
        }
    }
}

int main() {

    int i, j;
    char c;

    cout << "Enter number of productions: ";
    cin >> n;

    cout << "Enter productions (Example: S=AB):\n";

    for (i = 0; i < n; i++) {
        cin >> production[i];
    }

    cout << "\nFOLLOW Sets:\n";

    for (i = 0; i < n; i++) {

        c = production[i][0];
        m = 0;

        cout << "FOLLOW(" << c << ") = { ";

        findFollow(c);

        for (j = 0; j < m; j++) {
            cout << follow[j] << " ";
        }

        cout << "}\n";

        memset(follow, 0, sizeof(follow));
    }

    return 0;
}