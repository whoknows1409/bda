#include <iostream>
#include <stack>
#include <vector>
#include <iomanip>
#include <algorithm>

using namespace std;

struct Quadruple
{
    string op,arg1,arg2,result;
};

struct Triple
{
    string op,arg1,arg2;
};

int precedence(char ch)
{
    if(ch=='+' || ch=='-')
        return 1;

    if(ch=='*' || ch=='/')
        return 2;

    return 0;
}

bool isOperator(char ch)
{
    return ch=='+' || ch=='-' ||
           ch=='*' || ch=='/';
}

string infixToPostfix(string infix)
{
    stack<char> st;

    string postfix="";

    for(char ch : infix)
    {
        if(isalnum(ch))
        {
            postfix += ch;
        }

        else if(ch=='(')
        {
            st.push(ch);
        }

        else if(ch==')')
        {
            while(st.top()!='(')
            {
                postfix += st.top();
                st.pop();
            }

            st.pop();
        }

        else
        {
            while(!st.empty() &&
                  precedence(st.top()) >= precedence(ch))
            {
                postfix += st.top();
                st.pop();
            }

            st.push(ch);
        }
    }

    while(!st.empty())
    {
        postfix += st.top();
        st.pop();
    }

    return postfix;
}

string infixToPrefix(string infix)
{
    reverse(infix.begin(),infix.end());

    for(int i=0;i<infix.length();i++)
    {
        if(infix[i]=='(')
            infix[i]=')';

        else if(infix[i]==')')
            infix[i]='(';
    }

    string postfix=infixToPostfix(infix);

    reverse(postfix.begin(),postfix.end());

    return postfix;
}

string prefixToPostfix(string prefix)
{
    stack<string> st;

    for(int i=prefix.length()-1;i>=0;i--)
    {
        char ch=prefix[i];

        if(!isOperator(ch))
        {
            st.push(string(1,ch));
        }

        else
        {
            string op1=st.top();
            st.pop();

            string op2=st.top();
            st.pop();

            string temp=op1+op2+ch;

            st.push(temp);
        }
    }

    return st.top();
}

int main()
{
    string infix;

    cout << "Enter Infix Expression: ";
    cin >> infix;

    string prefix=infixToPrefix(infix);

    cout << "\nPrefix Expression: "
         << prefix << endl;

    string postfix=prefixToPostfix(prefix);

    stack<string> st;

    vector<Quadruple> quad;
    vector<Triple> triple;

    int tempCount=1;

    for(char ch : postfix)
    {
        if(!isOperator(ch))
        {
            st.push(string(1,ch));
        }

        else
        {
            string op2=st.top();
            st.pop();

            string op1=st.top();
            st.pop();

            string temp="t"+to_string(tempCount++);

            quad.push_back({string(1,ch),op1,op2,temp});

            triple.push_back({string(1,ch),op1,op2});

            st.push(temp);
        }
    }

    cout << "\nQUADRUPLES\n";

    cout << left
         << setw(10) << "Op"
         << setw(10) << "Arg1"
         << setw(10) << "Arg2"
         << setw(10) << "Result" << endl;

    for(auto q : quad)
    {
        cout << left
             << setw(10) << q.op
             << setw(10) << q.arg1
             << setw(10) << q.arg2
             << setw(10) << q.result << endl;
    }

    cout << "\nTRIPLES\n";

    cout << left
         << setw(10) << "Index"
         << setw(10) << "Op"
         << setw(10) << "Arg1"
         << setw(10) << "Arg2" << endl;

    for(int i=0;i<triple.size();i++)
    {
        cout << left
             << setw(10) << i
             << setw(10) << triple[i].op
             << setw(10) << triple[i].arg1
             << setw(10) << triple[i].arg2
             << endl;
    }

    return 0;
}