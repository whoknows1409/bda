#include <iostream>
#include <iomanip>
#include <vector>

using namespace std;

struct Block
{
    string blockName;
    int blockNumber;
    int startAddress;
    int length;
};

int main()
{
    int n;

    cout << "Enter Number of Lines in ASM Program: ";
    cin >> n;

    cin.ignore();

    vector<string> line(n);

    cout << "\nEnter ASM Program:\n";

    for(int i=0;i<n;i++)
    {
        getline(cin,line[i]);
    }

    vector<Block> blocks;

    int currentBlock = 0;
    int locctr = 0;

    string currentBlockName = "DEFAULT";

    blocks.push_back(
    {
        currentBlockName,
        0,
        0,
        0
    });

    /////////////////////////////////////////////////////////
    // PROCESS ASM CODE
    /////////////////////////////////////////////////////////

    for(int i=0;i<n;i++)
    {
        string stmt = line[i];

        /////////////////////////////////////////////////////
        // NEW PROGRAM BLOCK
        /////////////////////////////////////////////////////

        if(stmt.find("USE") != string::npos)
        {
            blocks[currentBlock].length = locctr;

            currentBlock++;

            currentBlockName =
                stmt.substr(stmt.find("USE")+4);

            locctr = 0;

            blocks.push_back(
            {
                currentBlockName,
                currentBlock,
                0,
                0
            });
        }

        /////////////////////////////////////////////////////
        // ASSUME EVERY INSTRUCTION = 3 BYTE
        /////////////////////////////////////////////////////

        else
        {
            locctr += 3;
        }
    }

    // Final block length
    blocks[currentBlock].length = locctr;

    /////////////////////////////////////////////////////////
    // ASSIGN START ADDRESSES
    /////////////////////////////////////////////////////////

    int address = 0;

    for(int i=0;i<blocks.size();i++)
    {
        blocks[i].startAddress = address;

        address += blocks[i].length;
    }

    /////////////////////////////////////////////////////////
    // PRINT BLOCK TABLE
    /////////////////////////////////////////////////////////

    cout << "\nBLOCK TABLE\n\n";

    cout << left
         << setw(15) << "Block Name"
         << setw(15) << "Block No"
         << setw(15) << "Start Addr"
         << setw(15) << "Length"
         << endl;

    for(auto b : blocks)
    {
        cout << left
             << setw(15) << b.blockName
             << setw(15) << b.blockNumber
             << setw(15) << b.startAddress
             << setw(15) << b.length
             << endl;
    }

    return 0;
}
/*
Enter Number of Lines in ASM Program: 12

COPY START 0000
LDA ALPHA
ADD ONE
USE BLOCK1
STA BETA
SUB TWO
USE BLOCK2
MUL THREE
DIV FOUR
USE DEFAULT
COMP FIVE
END

*/