#include <iostream>
#include <vector>
#include <iomanip>

using namespace std;

struct NameTab
{
    string macroName;
    int startIndex;
    int endIndex;
};

int main()
{
    int n;

    vector<string> asmCode;

    vector<string> deftab;

    vector<NameTab> nametab;

    /////////////////////////////////////////////////////////
    // INPUT ASM PROGRAM
    /////////////////////////////////////////////////////////

    cout << "Enter Number of Lines in ASM Program: ";
    cin >> n;

    cin.ignore();

    cout << "\nEnter ASM Program Line by Line:\n";

    for(int i = 0; i < n; i++)
    {
        string line;

        getline(cin, line);

        asmCode.push_back(line);
    }

    /////////////////////////////////////////////////////////
    // PROCESS MACROS
    /////////////////////////////////////////////////////////

    bool insideMacro = false;

    string macroName;

    int start, end;

    for(int i = 0; i < asmCode.size(); i++)
    {
        string line = asmCode[i];

        /////////////////////////////////////////////////////
        // START OF MACRO
        /////////////////////////////////////////////////////

        if(line == "MACRO")
        {
            insideMacro = true;

            start = deftab.size();

            // Next line contains macro prototype
            i++;

            string prototype = asmCode[i];

            deftab.push_back(prototype);

            // Extract macro name
            int pos = prototype.find(' ');

            if(pos != string::npos)
            {
                macroName = prototype.substr(0, pos);
            }
            else
            {
                macroName = prototype;
            }

            continue;
        }

        /////////////////////////////////////////////////////
        // STORE MACRO BODY
        /////////////////////////////////////////////////////

        if(insideMacro)
        {
            deftab.push_back(line);

            //////////////////////////////////////////////////
            // END OF MACRO
            //////////////////////////////////////////////////

            if(line == "MEND")
            {
                end = deftab.size() - 1;

                nametab.push_back(
                {
                    macroName,
                    start,
                    end
                });

                insideMacro = false;
            }
        }
    }

    /////////////////////////////////////////////////////////
    // PRINT DEFTAB
    /////////////////////////////////////////////////////////

    cout << "\nDEFINITION TABLE (DEFTAB)\n\n";

    cout << left
         << setw(10) << "Index"
         << "Definition" << endl;

    for(int i = 0; i < deftab.size(); i++)
    {
        cout << left
             << setw(10) << i
             << deftab[i]
             << endl;
    }

    /////////////////////////////////////////////////////////
    // PRINT NAMETAB
    /////////////////////////////////////////////////////////

    cout << "\nNAME TABLE (NAMETAB)\n\n";

    cout << left
         << setw(15) << "Macro Name"
         << setw(15) << "Start Index"
         << setw(15) << "End Index"
         << endl;

    for(auto x : nametab)
    {
        cout << left
             << setw(15) << x.macroName
             << setw(15) << x.startIndex
             << setw(15) << x.endIndex
             << endl;
    }

    return 0;
}