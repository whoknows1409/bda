#include <iostream>
#include <iomanip>
#include <map>

using namespace std;

int main()
{
    int n;

    string label[20];
    string opcode[20];
    string operand[20];

    map<string,int> symtab;

    int locctr = 0;
    int startAddress = 0;
    int programLength;

    /////////////////////////////////////////////////////////
    // INPUT
    /////////////////////////////////////////////////////////

    cout << "Enter Number of Statements: ";
    cin >> n;

    cout << "\nEnter Assembly Program\n";
    cout << "Format:\n";
    cout << "LABEL OPCODE OPERAND\n\n";

    for(int i=0;i<n;i++)
    {
        cin >> label[i]
            >> opcode[i]
            >> operand[i];
    }

    /////////////////////////////////////////////////////////
    // START ADDRESS
    /////////////////////////////////////////////////////////

    if(opcode[0] == "START")
    {
        startAddress = stoi(operand[0]);

        locctr = startAddress;
    }

    /////////////////////////////////////////////////////////
    // PASS 1 : GENERATE SYMBOL TABLE
    /////////////////////////////////////////////////////////

    for(int i=1;i<n;i++)
    {
        // Store label in symbol table
        if(label[i] != "-")
        {
            symtab[label[i]] = locctr;
        }

        /////////////////////////////////////////////////////
        // Instruction Length
        /////////////////////////////////////////////////////

        if(opcode[i] == "WORD")
        {
            locctr += 3;
        }

        else if(opcode[i] == "RESW")
        {
            locctr += 3 * stoi(operand[i]);
        }

        else if(opcode[i] == "RESB")
        {
            locctr += stoi(operand[i]);
        }

        else if(opcode[i] == "BYTE")
        {
            locctr += 1;
        }

        else if(opcode[i] == "END")
        {
            break;
        }

        else
        {
            // Assume normal instruction = 3 bytes
            locctr += 3;
        }
    }

    /////////////////////////////////////////////////////////
    // PROGRAM LENGTH
    /////////////////////////////////////////////////////////

    programLength = locctr - startAddress;

    /////////////////////////////////////////////////////////
    // PRINT SYMBOL TABLE
    /////////////////////////////////////////////////////////

    cout << "\nSYMBOL TABLE\n";

    cout << left
         << setw(15) << "Symbol Name"
         << setw(10) << "Value" << endl;

    for(auto x : symtab)
    {
        cout << left
             << setw(15) << x.first
             << setw(10) << x.second
             << endl;
    }

    /////////////////////////////////////////////////////////
    // HEADER RECORD
    /////////////////////////////////////////////////////////

    cout << "\nHEADER RECORD\n";

    cout << "H^"
         << label[0]
         << "^"
         << startAddress
         << "^"
         << programLength
         << endl;

    /////////////////////////////////////////////////////////
    // END RECORD
    /////////////////////////////////////////////////////////

    cout << "\nEND RECORD\n";

    cout << "E^"
         << startAddress
         << endl;

    return 0;
}

/*
Enter Number of Statements: 7

COPY START 1000
FIRST LDA ALPHA
- ADD ONE
- STA BETA
ALPHA WORD 5
BETA RESW 1
- END FIRST
*/