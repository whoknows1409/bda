#include <iostream>
#include <vector>
#include<sstream>
#include <set>
#include <iomanip>

using namespace std;

int main()
{
    int n;

    cout << "Enter Number of TAC Statements: ";
    cin >> n;

    cin.ignore();

    vector<string> tac(n);

    cout << "\nEnter TAC Statements:\n";

    for(int i = 0; i < n; i++)
    {
        getline(cin, tac[i]);
    }

    // Set to store leaders
    set<int> leaders;

    // First statement is always a leader
    leaders.insert(0);

    // Find leaders
    for(int i = 0; i < n; i++)
    {
        string stmt = tac[i];

        // Check for goto
        if(stmt.find("goto") != string::npos)
        {
            int target;

            // Find target line number
            size_t pos = stmt.find("goto");

            string num = stmt.substr(pos + 5);

            target = stoi(num);

            // Target statement becomes leader
            leaders.insert(target - 1);

            // Next statement also becomes leader
            if(i + 1 < n)
            {
                leaders.insert(i + 1);
            }
        }
    }

    /////////////////////////////////////////////////////////
    // PRINT LEADERS
    /////////////////////////////////////////////////////////

    cout << "\nLeaders are:\n";

    for(int leader : leaders)
    {
        cout << "Statement "
             << leader + 1 << endl;
    }

    /////////////////////////////////////////////////////////
    // STORE LEADERS IN VECTOR
    /////////////////////////////////////////////////////////

    vector<int> leaderList;

    for(int x : leaders)
    {
        leaderList.push_back(x);
    }

    /////////////////////////////////////////////////////////
    // PRINT BASIC BLOCKS
    /////////////////////////////////////////////////////////

    cout << "\nBASIC BLOCKS\n";

    int blockCount = 1;

    for(int i = 0; i < leaderList.size(); i++)
    {
        int start = leaderList[i];

        int end;

        // Last block
        if(i == leaderList.size() - 1)
        {
            end = n - 1;
        }

        else
        {
            end = leaderList[i + 1] - 1;
        }

        cout << "\nBasic Block "
             << blockCount++ << ":\n";

        for(int j = start; j <= end; j++)
        {
            cout << j + 1
                 << ". "
                 << tac[j] << endl;
        }
    }

    cout << "\nTotal Number of Basic Blocks: "
         << leaderList.size();

    return 0;
}

/*
Enter Number of TAC Statements: 8

a=b+c
if a<10 goto 6
d=a*2
e=d+1
goto 8
f=a+b
g=f*2
h=g+1
*/