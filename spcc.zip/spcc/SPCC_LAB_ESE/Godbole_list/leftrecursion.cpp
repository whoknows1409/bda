#include <iostream>
#include <string>
using namespace std;

int main() {
    string nonTerminal, production;
    
    cout << "Enter Non-Terminal: ";
    cin >> nonTerminal;

    cout << "Enter Production (use | symbol): ";
    cin >> production;

    string alpha = "", beta = "";
    int pos = production.find('|');

    string first = production.substr(0, pos);
    string second = production.substr(pos + 1);

    // Check left recursion
    if (first[0] == nonTerminal[0]) {
        alpha = first.substr(1);
        beta = second;
    } else {
        beta = first;
        alpha = second.substr(1);
    }

    cout << "\nAfter Removing Left Recursion:\n";

    cout << nonTerminal << " -> " << beta << nonTerminal << "'\n";
    cout << nonTerminal << "' -> " << alpha << nonTerminal << "' | e\n";

    return 0;
}