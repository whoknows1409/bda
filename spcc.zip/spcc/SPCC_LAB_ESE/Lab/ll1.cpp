#include <iostream>
#include <stack>
#include <string>
#include <unordered_map>

using namespace std;

/*
=====================================================
            LL(1) PARSER PROGRAM
=====================================================

Grammar Used:

        S -> (S)S | ε

Where:
S  = Start Symbol
ε  = Empty String

Accepted Strings:
(), (()),
()(), ((())) etc.

Rejected Strings:
)(, (() , ())(
=====================================================
*/

// Function to perform LL(1) Parsing
bool ll1parser(string input)
{
    // Append end marker
    input += '$';

    // Stack for parser
    stack<char> st;

    // Initialize stack with start symbol
    st.push('$');
    st.push('S');

    /*
        Predictive Parsing Table

              (        )        $
        --------------------------------
        S    S->(S)S    S->#    S->#

        # represents epsilon
    */

    unordered_map<char, string> parstable;

    parstable['('] = "(S)S";
    parstable[')'] = "#";
    parstable['$'] = "#";

    int i = 0;

    // Parsing Process
    while (!st.empty())
    {
        char top = st.top();

        char current = input[i];

        // If stack symbol matches input symbol
        if (top == current)
        {
            st.pop();

            i++;
        }

        // If top is non-terminal
        else if (top == 'S')
        {
            // Check parsing table
            if (parstable.find(current) != parstable.end())
            {
                string production = parstable[current];

                st.pop();

                // If production is not epsilon
                if (production != "#")
                {
                    // Push production in reverse order
                    for (int j = production.length() - 1; j >= 0; j--)
                    {
                        st.push(production[j]);
                    }
                }
            }

            // Invalid table entry
            else
            {
                return false;
            }
        }

        // Mismatch condition
        else
        {
            return false;
        }
    }

    // If entire input consumed successfully
    return (i == input.length());
}

// Main Function
int main()
{
    string input;

    cout << "=====================================\n";
    cout << "         LL(1) Parser Program\n";
    cout << "=====================================\n";

    cout << "\nGrammar Used:\n";
    cout << "S -> (S)S | #\n";

    cout << "\nEnter a string using only '(' and ')': ";

    cin >> input;

    // Validate input characters
    for (char c : input)
    {
        if (c != '(' && c != ')')
        {
            cout << "\nInvalid Input!\n";
            cout << "Only '(' and ')' are allowed.\n";

            return 0;
        }
    }

    // Check acceptance
    if (ll1parser(input))
    {
        cout << "\nString ACCEPTED by LL(1) Parser\n";
    }
    else
    {
        cout << "\nString REJECTED by LL(1) Parser\n";
    }

    return 0;
}