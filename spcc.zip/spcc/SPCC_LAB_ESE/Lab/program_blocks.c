#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/*
============================================================
        PROGRAM BLOCKS IMPLEMENTATION IN SYSTEM SOFTWARE
============================================================

This program:

1. Simulates Program Blocks
2. Handles USE Directive
3. Tracks LOCCTR Changes
4. Generates Block Table
5. Calculates Start Addresses and Lengths

------------------------------------------------------------
NO EXTERNAL input.asm FILE REQUIRED
------------------------------------------------------------

The Assembly Program is directly included in the code.

============================================================
*/

#define MAX_BLOCKS 10
#define MAX_LINES 100

/* =========================================================
                    BLOCK STRUCTURE
========================================================= */

typedef struct
{
    char name[20];

    int number;

    int locctr;

    int start_addr;

    int length;

} Block;

/* =========================================================
                LOCCTR TRACKING STRUCTURE
========================================================= */

typedef struct
{
    char statement[50];

    char block[20];

    int before;

    int after;

} Track;

/* =========================================================
                    GLOBAL VARIABLES
========================================================= */

Block blocks[MAX_BLOCKS];

Track track[MAX_LINES];

int block_count = 0;

int current_block = -1;

int start_address = 0x0000;

int track_count = 0;

/* =========================================================
        ASSEMBLY PROGRAM (DIRECTLY INSIDE CODE)
========================================================= */

char *program[] =
{
    "START 1000",

    "USE CODE",

    "LDA ALPHA",

    "STA BETA",

    "USE DATA",

    "ALPHA RESW 2",

    "BETA RESW 3",

    "USE EXTRA",

    "TEMP RESW 1",

    "USE CODE",

    "ADD ALPHA",

    "SUB TEMP",

    "USE DATA",

    "GAMMA RESW 1",

    "USE EXTRA",

    "DELTA RESW 2",

    "END"
};

int total_lines =
    sizeof(program) / sizeof(program[0]);

/* =========================================================
                FIND BLOCK BY NAME
========================================================= */

int findBlock(char *name)
{
    for (int i = 0; i < block_count; i++)
    {
        if (strcmp(blocks[i].name, name) == 0)
        {
            return i;
        }
    }

    return -1;
}

/* =========================================================
                CREATE NEW BLOCK
========================================================= */

int createBlock(char *name)
{
    strcpy(blocks[block_count].name, name);

    blocks[block_count].number = block_count;

    blocks[block_count].locctr = 0;

    blocks[block_count].start_addr = 0;

    blocks[block_count].length = 0;

    return block_count++;
}

/* =========================================================
                SWITCH CURRENT BLOCK
========================================================= */

void switchBlock(char *name)
{
    int idx = findBlock(name);

    if (idx == -1)
    {
        idx = createBlock(name);
    }

    current_block = idx;
}

/* =========================================================
            ADD BYTES AND TRACK LOCCTR
========================================================= */

void addBytes(char *stmt, int bytes)
{
    int before = blocks[current_block].locctr;

    blocks[current_block].locctr += bytes;

    int after = blocks[current_block].locctr;

    strcpy(track[track_count].statement, stmt);

    strcpy(track[track_count].block,
           blocks[current_block].name);

    track[track_count].before = before;

    track[track_count].after = after;

    track_count++;
}

/* =========================================================
            ASSIGN START ADDRESSES TO BLOCKS
========================================================= */

void assignAddresses()
{
    int addr = start_address;

    for (int i = 0; i < block_count; i++)
    {
        blocks[i].start_addr = addr;

        blocks[i].length = blocks[i].locctr;

        addr += blocks[i].length;
    }
}

/* =========================================================
                        MAIN FUNCTION
========================================================= */

int main()
{
    char line[100];

    char w1[20], w2[20], w3[20];

    printf("============================================================\n");

    printf("              PROGRAM BLOCKS IMPLEMENTATION\n");

    printf("============================================================\n");

    /* =====================================================
                PROCESS EACH ASSEMBLY LINE
    ===================================================== */

    for (int k = 0; k < total_lines; k++)
    {
        strcpy(line, program[k]);

        strcpy(w1, "");

        strcpy(w2, "");

        strcpy(w3, "");

        sscanf(line, "%s %s %s", w1, w2, w3);

        /* START Directive */
        if (strcmp(w1, "START") == 0)
        {
            start_address =
                (int)strtol(w2, NULL, 16);

            continue;
        }

        /* USE Directive */
        if (strcmp(w1, "USE") == 0)
        {
            switchBlock(w2);

            continue;
        }

        /* Machine Instructions */
        if (strcmp(w1, "LDA") == 0 ||
            strcmp(w1, "STA") == 0 ||
            strcmp(w1, "ADD") == 0 ||
            strcmp(w1, "SUB") == 0)
        {
            addBytes(line, 3);

            continue;
        }

        /* RESW Directive */
        if (strcmp(w2, "RESW") == 0)
        {
            int val = atoi(w3);

            addBytes(line, val * 3);

            continue;
        }

        /* END Directive */
        if (strcmp(w1, "END") == 0)
        {
            break;
        }
    }

    /* =====================================================
                ASSIGN FINAL ADDRESSES
    ===================================================== */

    assignAddresses();

    /* =====================================================
                LOCCTR TRACKING TABLE
    ===================================================== */

    printf("\n============================================================\n");

    printf("                 LOCCTR TRACKING TABLE\n");

    printf("============================================================\n");

    printf("%-25s %-10s %-10s %-10s\n",
           "Statement",
           "Block",
           "Before",
           "After");

    printf("------------------------------------------------------------\n");

    for (int i = 0; i < track_count; i++)
    {
        printf("%-25s %-10s %04X      %04X\n",
               track[i].statement,
               track[i].block,
               track[i].before,
               track[i].after);
    }

    /* =====================================================
                        BLOCK TABLE
    ===================================================== */

    printf("\n============================================================\n");

    printf("                        BLOCK TABLE\n");

    printf("============================================================\n");

    printf("%-10s %-10s %-15s %-10s\n",
           "Block No",
           "Name",
           "Start Addr",
           "Length");

    printf("------------------------------------------------------------\n");

    for (int i = 0; i < block_count; i++)
    {
        printf("%-10d %-10s %04X           %04X\n",
               blocks[i].number,
               blocks[i].name,
               blocks[i].start_addr,
               blocks[i].length);
    }

    /* =====================================================
            LOCATION COUNTER CALCULATION
    ===================================================== */

    printf("\n============================================================\n");

    printf("             LOCATION COUNTER CALCULATION\n");

    printf("============================================================\n");

    for (int i = 0; i < block_count; i++)
    {
        printf("\n%s BLOCK:\n", blocks[i].name);

        int total = 0;

        for (int j = 0; j < track_count; j++)
        {
            if (strcmp(track[j].block,
                       blocks[i].name) == 0)
            {
                int size =
                    track[j].after - track[j].before;

                printf("%-25s (%d bytes)\n",
                       track[j].statement,
                       size);

                total += size;
            }
        }

        printf("Total = %d bytes\n", total);
    }

    printf("\n============================================================\n");

    return 0;
}

/*
============================================================
                COMMANDS TO RUN
============================================================

1. Compile Program:

        gcc program_blocks.c -o program_blocks

2. Run Program:

        ./program_blocks

============================================================
*/