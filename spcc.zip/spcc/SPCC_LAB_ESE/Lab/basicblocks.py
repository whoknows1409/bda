"""
============================================================
        BASIC BLOCKS AND FLOW GRAPH GENERATION
============================================================

This program:

1. Accepts Three Address Code (TAC)
2. Identifies Leaders
3. Forms Basic Blocks
4. Generates Flow Graph Edges

------------------------------------------------------------
SAMPLE INPUT (WITHOUT ERROR)
------------------------------------------------------------

a = b + c
if a < 10 goto 5
d = a * 2
goto 6
e = d + 1
f = e - 2
DONE

------------------------------------------------------------
EXPECTED OUTPUT
------------------------------------------------------------

Number of basic blocks: 4

Flow Graph:

--- Block 1 ---
a = b + c
if a < 10 goto Block 3
 -> Edges: Block 2, Block 3

--- Block 2 ---
d = a * 2
goto Block 4
 -> Edges: Block 4

--- Block 3 ---
e = d + 1
 -> Edges: Block 4

--- Block 4 ---
f = e - 2
 -> Edges: Exit

------------------------------------------------------------
SAMPLE INPUT (WITH ERROR)
------------------------------------------------------------

a = b + c
goto 10
DONE

------------------------------------------------------------
EXPECTED OUTPUT
------------------------------------------------------------

Error: target not found for line 2

============================================================
"""

def main():

    print("==================================================")
    print("   BASIC BLOCKS AND FLOW GRAPH GENERATION")
    print("==================================================")

    print("\nEnter TAC in sequence")
    print("Type 'DONE' to stop input\n")

    code = []

    # ======================================================
    # INPUT TAC LINES
    # ======================================================

    while True:

        line = input().strip()

        if line == "DONE":
            break

        if line:
            code.append(line)

    # Empty Input Check
    if not code:
        print("\nNo TAC entered.")
        return

    # ======================================================
    # STEP 1: IDENTIFY LEADERS
    # ======================================================

    leaders = {1}

    for i, line in enumerate(code):

        tokens = line.split()

        # Check for goto statements
        if 'goto' in tokens:

            target_index = tokens.index('goto') + 1

            # Validate target existence
            if target_index < len(tokens):

                target_line = int(tokens[target_index])

                # Valid target check
                if 1 <= target_line <= len(code):

                    leaders.add(target_line)

                else:
                    print(f"\nError: target not found for line {i + 1}")
                    return

            else:
                print(f"\nError: target not found for line {i + 1}")
                return

            # Next statement after goto becomes leader
            if i + 1 < len(code):

                leaders.add(i + 2)

            else:
                print(f"\nError: next line not found for line {i + 1}")
                return

    leaders = sorted(list(leaders))

    # ======================================================
    # STEP 2: FORM BASIC BLOCKS
    # ======================================================

    blocks = []

    for i in range(len(leaders)):

        start = leaders[i]

        if i + 1 < len(leaders):
            end = leaders[i + 1] - 1
        else:
            end = len(code)

        blocks.append((start, end))

    # ======================================================
    # HELPER FUNCTION:
    # FIND BLOCK NUMBER FROM LINE NUMBER
    # ======================================================

    def get_target_block(line_num):

        for j, block in enumerate(blocks, 1):

            if block[0] == line_num:
                return j

        return None

    # ======================================================
    # DISPLAY NUMBER OF BASIC BLOCKS
    # ======================================================

    print(f"\nNumber of Basic Blocks: {len(blocks)}")

    # ======================================================
    # FLOW GRAPH
    # ======================================================

    print("\n================ FLOW GRAPH ================")

    for i, (start, end) in enumerate(blocks):

        block_num = i + 1

        print(f"\n--- Block {block_num} ---")

        # Print Statements
        for line_idx in range(start - 1, end):

            statement = code[line_idx]

            tokens = statement.split()

            # Replace goto target with block number
            if 'goto' in tokens:

                goto_index = tokens.index('goto')

                if (goto_index + 1 < len(tokens) and
                        tokens[goto_index + 1].isdigit()):

                    target_line = int(tokens[goto_index + 1])

                    target_block = get_target_block(target_line)

                    if target_block is not None:

                        tokens[goto_index + 1] = f"Block {target_block}"

                        statement = " ".join(tokens)

            print(" ", statement)

        # ==================================================
        # DETERMINE SUCCESSOR BLOCKS
        # ==================================================

        last_line = code[end - 1].split()

        successors = []

        # goto statement
        if 'goto' in last_line:

            target = int(last_line[last_line.index('goto') + 1])

            target_block = get_target_block(target)

            if target_block is not None:

                successors.append(target_block)

            # Conditional Jump
            if 'if' in last_line and block_num < len(blocks):

                successors.append(block_num + 1)

        # Normal Flow
        elif block_num < len(blocks):

            successors.append(block_num + 1)

        successors = sorted(list(set(successors)))

        # ==================================================
        # PRINT EDGES
        # ==================================================

        if successors:

            successor_string = ", ".join(
                f"Block {s}" for s in successors
            )

        else:

            successor_string = "Exit"

        print(f" -> Edges: {successor_string}")

    print("\n==================================================")


# ==========================================================
# MAIN FUNCTION
# ==========================================================

if __name__ == "__main__":

    main()