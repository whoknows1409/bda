#include <iostream>
#include <vector>
#include <string>
#include <stack>
#include <set>
#include <map>
#include <queue>
#include <algorithm>
#include <iomanip>

using namespace std;

// ================= DATA STRUCTURES =================

enum NodeType
{
    LEAF,
    OR,
    CONCAT,
    STAR
};

struct Node
{
    NodeType type;
    char symbol;
    int pos;

    Node *left;
    Node *right;

    bool nullable;
    set<int> firstpos;
    set<int> lastpos;

    int id;

    Node(NodeType t = LEAF, char s = '\0')
    {
        type = t;
        symbol = s;
        pos = 0;

        left = nullptr;
        right = nullptr;

        nullable = false;
        id = -1;
    }
};

// ================= HELPER FUNCTIONS =================

bool isOperand(char c)
{
    return isalnum(c) || c == '#' || c == 'E';
}

string addConcat(const string &re)
{
    string out;

    for (size_t i = 0; i < re.size(); ++i)
    {
        char c = re[i];
        out.push_back(c);

        if (i + 1 < re.size())
        {
            char next = re[i + 1];

            if ((isOperand(c) || c == ')' || c == '*') &&
                (isOperand(next) || next == '('))
            {
                out.push_back('.');
            }
        }
    }

    return out;
}

int precedence(char op)
{
    if (op == '*')
        return 3;

    if (op == '.')
        return 2;

    if (op == '|')
        return 1;

    return 0;
}

string toPostfix(const string &re)
{
    string out;
    stack<char> st;

    for (char c : re)
    {
        if (c == '(')
        {
            st.push(c);
        }
        else if (c == ')')
        {
            while (!st.empty() && st.top() != '(')
            {
                out.push_back(st.top());
                st.pop();
            }

            if (!st.empty())
                st.pop();
        }
        else if (c == '|' || c == '.' || c == '*')
        {
            while (!st.empty() &&
                   precedence(st.top()) >= precedence(c))
            {
                out.push_back(st.top());
                st.pop();
            }

            st.push(c);
        }
        else
        {
            out.push_back(c);
        }
    }

    while (!st.empty())
    {
        out.push_back(st.top());
        st.pop();
    }

    return out;
}

string setToString(const set<int> &s)
{
    if (s.empty())
        return "{}";

    string out = "{";

    for (auto it = s.begin(); it != s.end(); ++it)
    {
        out += to_string(*it);

        if (next(it) != s.end())
            out += ",";
    }

    out += "}";

    return out;
}

// ================= GLOBAL =================

vector<Node *> allNodes;

// ================= BUILD SYNTAX TREE =================

Node *buildTree(const string &postfix,
                map<int, char> &pos2sym,
                int &posCount)
{
    stack<Node *> st;
    int nodeId = 1;

    for (char c : postfix)
    {
        Node *n;

        if (c == '*')
        {
            Node *a = st.top();
            st.pop();

            n = new Node(STAR);
            n->left = a;
        }
        else if (c == '.' || c == '|')
        {
            Node *b = st.top();
            st.pop();

            Node *a = st.top();
            st.pop();

            n = new Node(c == '.' ? CONCAT : OR);

            n->left = a;
            n->right = b;
        }
        else
        {
            n = new Node(LEAF, c);

            if (c != 'E')
            {
                n->pos = ++posCount;
                pos2sym[n->pos] = c;
            }
        }

        n->id = nodeId++;

        allNodes.push_back(n);
        st.push(n);
    }

    return st.top();
}

// ================= COMPUTE FUNCTIONS =================

void computeFunctions(Node *root)
{
    if (!root)
        return;

    computeFunctions(root->left);
    computeFunctions(root->right);

    // ---------- LEAF ----------
    if (root->type == LEAF)
    {
        root->nullable = (root->symbol == 'E');

        if (root->pos > 0)
        {
            root->firstpos.insert(root->pos);
            root->lastpos.insert(root->pos);
        }
    }

    // ---------- OR ----------
    else if (root->type == OR)
    {
        root->nullable =
            root->left->nullable ||
            root->right->nullable;

        root->firstpos = root->left->firstpos;

        root->firstpos.insert(
            root->right->firstpos.begin(),
            root->right->firstpos.end());

        root->lastpos = root->left->lastpos;

        root->lastpos.insert(
            root->right->lastpos.begin(),
            root->right->lastpos.end());
    }

    // ---------- CONCAT ----------
    else if (root->type == CONCAT)
    {
        root->nullable =
            root->left->nullable &&
            root->right->nullable;

        root->firstpos = root->left->firstpos;

        if (root->left->nullable)
        {
            root->firstpos.insert(
                root->right->firstpos.begin(),
                root->right->firstpos.end());
        }

        root->lastpos = root->right->lastpos;

        if (root->right->nullable)
        {
            root->lastpos.insert(
                root->left->lastpos.begin(),
                root->left->lastpos.end());
        }
    }

    // ---------- STAR ----------
    else if (root->type == STAR)
    {
        root->nullable = true;

        root->firstpos = root->left->firstpos;
        root->lastpos = root->left->lastpos;
    }
}

// ================= MAIN =================

int main()
{
    string input;

    cout << "Enter Regular Expression: ";
    getline(cin, input);

    // Remove spaces
    string clean;

    for (char c : input)
    {
        if (!isspace(c))
            clean += c;
    }

    // Add end marker #
    string augmented = "(" + clean + ")#";

    // Add explicit concatenation operator
    string withDots = addConcat(augmented);

    // Convert to postfix
    string postfix = toPostfix(withDots);

    map<int, char> pos2sym;
    int posCount = 0;

    // Build syntax tree
    Node *root = buildTree(postfix, pos2sym, posCount);

    // Compute nullable, firstpos, lastpos
    computeFunctions(root);

    // ================= NODE ANALYSIS =================

    cout << "\n[1] Node Analysis Table\n";

    cout << "--------------------------------------------------------------------------\n";

    cout << left
         << setw(5) << "ID"
         << setw(10) << "Type"
         << setw(8) << "Sym"
         << setw(12) << "Nullable"
         << setw(20) << "Firstpos"
         << "Lastpos\n";

    cout << "--------------------------------------------------------------------------\n";

    for (Node *n : allNodes)
    {
        string t;

        switch (n->type)
        {
        case LEAF:
            t = "LEAF";
            break;

        case OR:
            t = "OR";
            break;

        case CONCAT:
            t = "CONCAT";
            break;

        case STAR:
            t = "STAR";
            break;
        }

        cout << left
             << setw(5) << n->id
             << setw(10) << t
             << setw(8)
             << (n->symbol ? string(1, n->symbol) : "-")
             << setw(12)
             << (n->nullable ? "Yes" : "No")
             << setw(20)
             << setToString(n->firstpos)
             << setToString(n->lastpos)
             << endl;
    }

    // ================= FOLLOWPOS =================

    vector<set<int>> followpos(posCount + 1);

    for (Node *n : allNodes)
    {
        // CONCAT rule
        if (n->type == CONCAT)
        {
            for (int i : n->left->lastpos)
            {
                followpos[i].insert(
                    n->right->firstpos.begin(),
                    n->right->firstpos.end());
            }
        }

        // STAR rule
        else if (n->type == STAR)
        {
            for (int i : n->left->lastpos)
            {
                followpos[i].insert(
                    n->left->firstpos.begin(),
                    n->left->firstpos.end());
            }
        }
    }

    cout << "\n[2] Followpos Table\n";

    cout << "-------------------------------------\n";

    for (int i = 1; i <= posCount; ++i)
    {
        cout << "Pos "
             << i
             << " ("
             << pos2sym[i]
             << ") : "
             << setToString(followpos[i])
             << endl;
    }

    // ================= DFA CONSTRUCTION =================

    set<char> alphabet;

    for (auto &[p, s] : pos2sym)
    {
        if (s != '#')
            alphabet.insert(s);
    }

    map<set<int>, int> stateMap;
    vector<set<int>> states;
    queue<set<int>> q;

    set<int> start = root->firstpos;

    states.push_back(start);
    stateMap[start] = 0;

    q.push(start);

    map<int, map<char, int>> dfa;

    int stateCount = 1;

    while (!q.empty())
    {
        set<int> T = q.front();
        q.pop();

        int tid = stateMap[T];

        for (char a : alphabet)
        {
            set<int> U;

            for (int p : T)
            {
                if (pos2sym[p] == a)
                {
                    U.insert(
                        followpos[p].begin(),
                        followpos[p].end());
                }
            }

            if (!U.empty())
            {
                if (!stateMap.count(U))
                {
                    stateMap[U] = stateCount++;

                    states.push_back(U);
                    q.push(U);
                }

                dfa[tid][a] = stateMap[U];
            }
        }
    }

    // ================= DFA TABLE =================

    cout << "\n[3] DFA Transition Table\n";

    cout << "--------------------------------------------------------------------------------\n";

    cout << left
         << setw(15) << "DFA State"
         << setw(25) << "Positions";

    for (char a : alphabet)
    {
        cout << left << setw(10) << a;
    }

    cout << "Accepting\n";

    cout << "--------------------------------------------------------------------------------\n";

    for (int i = 0; i < states.size(); ++i)
    {
        cout << left
             << setw(15)
             << ("S" + to_string(i))

             << setw(25)
             << setToString(states[i]);

        for (char a : alphabet)
        {
            if (dfa[i].count(a))
            {
                cout << left
                     << setw(10)
                     << ("S" + to_string(dfa[i][a]));
            }
            else
            {
                cout << left
                     << setw(10)
                     << "-";
            }
        }

        bool accepting = false;

        for (int p : states[i])
        {
            if (pos2sym[p] == '#')
            {
                accepting = true;
            }
        }

        cout << (accepting ? "Yes" : "No") << endl;
    }

    // ================= CLEANUP =================

    for (Node *n : allNodes)
    {
        delete n;
    }

    return 0;
}