"""
============================================================
                MACRO PROCESSOR
           (PASS 1 + PASS 2 IMPLEMENTATION)
============================================================

This program performs:

1. PASS 1
   - Creates MDT (Macro Definition Table)
   - Creates MNT (Macro Name Table)

2. PASS 2
   - Expands Macro Calls
   - Creates Argument Tables
   - Generates Expanded Code

------------------------------------------------------------
NO EXTERNAL FILE REQUIRED
------------------------------------------------------------

The assembly program is directly included in the code.

============================================================
"""

# ==========================================================
# INPUT ASSEMBLY PROGRAM
# ==========================================================

assembly_program = [

    "PG1 START 1000",

    "M1 MACRO &P1 , &P2",

    "LDA $ADD1",

    "$ADD1 STA &P1",

    "STB &P2",

    "ADD &P1-->1",

    "MEND",

    "M1 XYZ1 , PQR1",

    "SUB ??",

    "M1 XYZ2 , PQR2",

    "END"
]


# ==========================================================
# PASS 1
# CREATE MDT + MNT
# ==========================================================

def pass1(lines):

    MNT = []

    MDT = []

    mdt_index = 1

    in_macro = False

    params = []

    macro_name = ""

    for line in lines:

        tokens = line.split()

        # Detect MACRO definition
        if "MACRO" in line:

            in_macro = True

            macro_name = tokens[0]

            params = [
                p.replace("&", "")
                for p in tokens[2:]
                if p != ","
            ]

            start_ptr = mdt_index

            MDT.append([
                mdt_index,
                macro_name,
                "MACRO",
                " ".join(tokens[2:])
            ])

            mdt_index += 1

        # Detect MEND
        elif "MEND" in line:

            MDT.append([
                mdt_index,
                "",
                "MEND",
                ""
            ])

            end_ptr = mdt_index

            mdt_index += 1

            in_macro = False

            # Store in MNT
            MNT.append([
                macro_name,
                start_ptr,
                end_ptr
            ])

        # Macro Body
        elif in_macro:

            # Replace parameters with positional notation
            for i, p in enumerate(params):

                line = line.replace(
                    "&" + p,
                    f"?{i+1}"
                )

            parts = line.split(maxsplit=1)

            mnemonic = parts[0]

            operand = parts[1] if len(parts) > 1 else ""

            MDT.append([
                mdt_index,
                "",
                mnemonic,
                operand
            ])

            mdt_index += 1

    return MNT, MDT


# ==========================================================
# PASS 2
# MACRO EXPANSION
# ==========================================================

def pass2(lines, MNT, MDT):

    expanded = []

    arg_tables = []

    inside_macro = False

    for line in lines:

        tokens = line.split()

        # Skip Macro Definition
        if "MACRO" in line:

            inside_macro = True

            continue

        if "MEND" in line:

            inside_macro = False

            continue

        if inside_macro:

            continue

        # ==================================================
        # HANDLE MACRO CALL
        # ==================================================

        if tokens[0] == "M1":

            args = [
                a.replace(",", "")
                for a in tokens[1:]
                if a != ","
            ]

            arg_tables.append(args)

            # Add Comment Line
            expanded.append(
                f"** comment {line} **"
            )

            start = MNT[0][1]

            end = MNT[0][2]

            # Expand Macro
            for row in MDT:

                if start < row[0] < end:

                    # Skip MEND
                    if row[2] == "MEND":

                        continue

                    label = row[1]

                    mnemonic = row[2]

                    operand = row[3]

                    # Replace positional parameters
                    for i, val in enumerate(args):

                        operand = operand.replace(
                            f"?{i+1}",
                            val
                        )

                    # Construct expanded line
                    if label:

                        expanded.append(
                            f"{label} {mnemonic} {operand}"
                        )

                    else:

                        expanded.append(
                            f"{mnemonic} {operand}".strip()
                        )

        else:

            expanded.append(line)

    return arg_tables, expanded


# ==========================================================
# PRINT TABLES
# ==========================================================

def print_tables(MNT, MDT, arg_tables, expanded):

    # ======================================================
    # MDT
    # ======================================================

    print("\n==================================================")
    print("         MACRO DEFINITION TABLE (MDT)")
    print("==================================================")

    print(f"{'INDEX':<10}"
          f"{'LABEL':<15}"
          f"{'MNEMONIC':<15}"
          f"{'OPERAND'}")

    for row in MDT:

        print(f"{row[0]:<10}"
              f"{row[1]:<15}"
              f"{row[2]:<15}"
              f"{row[3]}")

    # ======================================================
    # MNT
    # ======================================================

    print("\n==================================================")
    print("           MACRO NAME TABLE (MNT)")
    print("==================================================")

    print(f"{'MACRO NAME':<20}"
          f"{'START PTR':<15}"
          f"{'END PTR'}")

    for row in MNT:

        print(f"{row[0]:<20}"
              f"{row[1]:<15}"
              f"{row[2]}")

    # ======================================================
    # ARGUMENT TABLES
    # ======================================================

    print("\n==================================================")
    print("               ARGUMENT TABLES")
    print("==================================================")

    for i, args in enumerate(arg_tables):

        print(f"\nARGUMENT TABLE FOR CALL {i+1}")

        print(f"{'INDEX':<10}"
              f"{'ARGUMENT'}")

        for j, arg in enumerate(args):

            print(f"{j+1:<10}{arg}")

    # ======================================================
    # EXPANDED CODE
    # ======================================================

    print("\n==================================================")
    print("                EXPANDED CODE")
    print("==================================================")

    print(f"{'LINE':<10}CODE")

    for i, line in enumerate(expanded, 1):

        print(f"{i:<10}{line}")


# ==========================================================
# MAIN FUNCTION
# ==========================================================

def main():

    # PASS 1
    MNT, MDT = pass1(assembly_program)

    # PASS 2
    arg_tables, expanded = pass2(
        assembly_program,
        MNT,
        MDT
    )

    # PRINT OUTPUT
    print_tables(
        MNT,
        MDT,
        arg_tables,
        expanded
    )


# ==========================================================
# DRIVER CODE
# ==========================================================

if __name__ == "__main__":

    main()


"""
============================================================
                COMMAND TO RUN
============================================================

1. Save file as:
        macro_processor.py

2. Run using:
        python3 macro_processor.py

============================================================
"""