#include <iostream>
#include <string>
#include <cctype>
#include <vector>

using namespace std;

// Function to print the State Transition Diagram
void printTransitionDiagram()
{
    cout << "\n=========== STATE TRANSITION DIAGRAM (C LANGUAGE) ===========\n";

    cout << "\n";
    cout << "        (Letter / _)\n";
    cout << "      +----------------+\n";
    cout << "      |                v\n";
    cout << "--> [ STATE 0 ] ----> [ STATE 1 ]   (Identifier / Keyword)\n";
    cout << "      |   START           ^\n";
    cout << "      |                   |\n";
    cout << "      +-------------------+\n";
    cout << "         (Alphanumeric / _)\n";

    cout << "\n";
    cout << "        (Digit)\n";
    cout << "      +----------------+\n";
    cout << "      |                v\n";
    cout << "      +------------> [ STATE 2 ]   (Integer / Float)\n";
    cout << "                         ^\n";
    cout << "                         |\n";
    cout << "                 (Digit or .)\n";

    cout << "\n";
    cout << "       '/' followed by '/'\n";
    cout << "      +----------------+\n";
    cout << "      |                v\n";
    cout << "      +------------> [ STATE 4 ]   (Single Line Comment)\n";
    cout << "                         |\n";
    cout << "                         |\n";
    cout << "                    (Until Newline)\n";

    cout << "\n=============================================================\n";
}

// Function to check keywords
string checkKeywordType(string str)
{
    string keywords[] =
    {
        "auto", "break", "case", "char", "const", "continue",
        "default", "do", "double", "else", "enum", "extern",
        "float", "for", "goto", "if", "int", "long",
        "register", "return", "short", "signed", "sizeof",
        "static", "struct", "switch", "typedef", "union",
        "unsigned", "void", "volatile", "while"
    };

    for (const string &k : keywords)
    {
        if (str == k)
            return "Keyword";
    }

    return "Identifier";
}

// Lexical Analyzer Function
void analyzeCode(string input)
{
    int state = 0;
    string lexeme = "";

    input += '\n';

    cout << "\n================ TOKENS =================\n";
    cout << "Category\t\tValue\n";
    cout << "-----------------------------------------\n";

    for (int i = 0; i < input.length(); i++)
    {
        char ch = input[i];

        switch (state)
        {
            // START STATE
            case 0:

                if (isspace(ch))
                {
                    continue;
                }

                // Identifier or Keyword
                else if (isalpha(ch) || ch == '_')
                {
                    state = 1;
                    lexeme += ch;
                }

                // Number
                else if (isdigit(ch))
                {
                    state = 2;
                    lexeme += ch;
                }

                // Operators and Comments
                else if (ch == '+' || ch == '-' || ch == '*' ||
                         ch == '/' || ch == '%' || ch == '=' ||
                         ch == '!' || ch == '<' || ch == '>' ||
                         ch == '&' || ch == '|')
                {
                    // Single line comment //
                    if (ch == '/' && i + 1 < input.length() && input[i + 1] == '/')
                    {
                        state = 4;
                        i++;
                        continue;
                    }

                    // Two character operators
                    if (i + 1 < input.length())
                    {
                        char nextCh = input[i + 1];

                        if ((ch == '+' && nextCh == '+') ||
                            (ch == '-' && nextCh == '-') ||
                            (ch == '&' && nextCh == '&') ||
                            (ch == '|' && nextCh == '|') ||
                            (ch == '=' && nextCh == '=') ||
                            (ch == '!' && nextCh == '=') ||
                            (ch == '<' && nextCh == '=') ||
                            (ch == '>' && nextCh == '='))
                        {
                            string op = string(1, ch) + string(1, nextCh);

                            if (op == "&&" || op == "||")
                                cout << "Logical Op\t\t" << op << endl;

                            else if (op == "==" || op == "!=" ||
                                     op == "<=" || op == ">=")
                                cout << "Relational Op\t\t" << op << endl;

                            else
                                cout << "Arithmetic Op\t\t" << op << endl;

                            i++;
                            continue;
                        }
                    }

                    // Single character operators
                    if (ch == '!')
                        cout << "Logical Op\t\t" << ch << endl;

                    else if (ch == '<' || ch == '>')
                        cout << "Relational Op\t\t" << ch << endl;

                    else if (ch == '=')
                        cout << "Assignment Op\t\t" << ch << endl;

                    else if (ch == '&' || ch == '|')
                        cout << "Bitwise Op\t\t" << ch << endl;

                    else
                        cout << "Arithmetic Op\t\t" << ch << endl;
                }

                // Delimiters
                else
                {
                    cout << "Delimiter\t\t" << ch << endl;
                }

                break;

            // IDENTIFIER OR KEYWORD
            case 1:

                if (isalnum(ch) || ch == '_')
                {
                    lexeme += ch;
                }
                else
                {
                    string type = checkKeywordType(lexeme);

                    if (type == "Keyword")
                        cout << type << "\t\t\t" << lexeme << endl;

                    else
                        cout << type << "\t\t" << lexeme << endl;

                    lexeme = "";
                    state = 0;
                    i--;
                }

                break;

            // NUMBER
            case 2:

                if (isdigit(ch) || ch == '.')
                {
                    lexeme += ch;
                }
                else
                {
                    if (lexeme.find('.') != string::npos)
                        cout << "Float\t\t\t" << lexeme << endl;

                    else
                        cout << "Integer\t\t\t" << lexeme << endl;

                    lexeme = "";
                    state = 0;
                    i--;
                }

                break;

            // COMMENT
            case 4:

                if (ch == '\n')
                {
                    state = 0;
                }

                break;
        }
    }
}

// Main Function
int main()
{
    printTransitionDiagram();

    string fullCode = "";
    string line;

    cout << "\n=== C Language Lexical Analyzer ===\n";
    cout << "Enter your C code below.\n";
    cout << "Type 'END' on a new line to stop.\n\n";

    while (true)
    {
        getline(cin, line);

        if (line == "END")
            break;

        fullCode += line + "\n";
    }

    if (fullCode.empty())
    {
        cout << "No code entered.\n";
    }
    else
    {
        analyzeCode(fullCode);
    }

    return 0;
}