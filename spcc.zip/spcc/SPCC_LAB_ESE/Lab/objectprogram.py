"""
============================================================
            SIC ASSEMBLER (PASS 1 + PASS 2)
============================================================

This program performs:

1. PASS 1
   - Generates Symbol Table
   - Assigns Addresses
   - Creates Intermediate Code

2. PASS 2
   - Generates Object Code
   - Generates Header, Text and End Records

------------------------------------------------------------
SUPPORTED INSTRUCTIONS
------------------------------------------------------------

JMP
LDA
STA

------------------------------------------------------------
DIRECTIVES SUPPORTED
------------------------------------------------------------

START
WORD
RESW
RESB
BYTE
EQU
END

============================================================
"""

# ==========================================================
# OPCODE TABLE
# ==========================================================

OPCODES = {
    "JMP": "10",
    "STA": "20",
    "LDA": "00"
}


# ==========================================================
# FUNCTION:
# CONVERT ASCII STRING TO HEX
# ==========================================================

def ascii_to_hex(s):

    return ''.join(format(ord(c), '02X') for c in s)


# ==========================================================
# PASS 1
# GENERATE SYMBOL TABLE + INTERMEDIATE CODE
# ==========================================================

def pass1(program):

    # Starting Address
    locctr = int(program[0][2], 16)

    symtab = {}

    intermediate = []

    for line in program:

        label, opcode, operand = line

        # START Directive
        if opcode == "START":

            intermediate.append(
                (locctr, label, opcode, operand)
            )

            continue

        # Store Labels in Symbol Table
        if label != "-":

            symtab[label] = locctr

        # Machine Instructions
        if opcode in OPCODES:

            locctr += 3

        # WORD
        elif opcode == "WORD":

            locctr += 3

        # RESW
        elif opcode == "RESW":

            locctr += 3 * int(operand)

        # RESB
        elif opcode == "RESB":

            locctr += int(operand)

        # BYTE
        elif opcode == "BYTE":

            # Character Constant
            if operand.startswith("C"):

                locctr += len(operand) - 3

            # Hex Constant
            elif operand.startswith("X"):

                locctr += (len(operand) - 3) // 2

        # EQU Directive
        elif opcode == "EQU":

            symtab[label] = int(operand)

        # END Directive
        elif opcode == "END":

            intermediate.append(
                (locctr, label, opcode, operand)
            )

            break

        # Store Intermediate Code
        intermediate.append(
            (locctr, label, opcode, operand)
        )

    # Program Length
    program_length = (
        locctr - int(program[0][2], 16)
    )

    return symtab, intermediate, program_length


# ==========================================================
# PASS 2
# GENERATE OBJECT CODE
# ==========================================================

def pass2(intermediate, symtab, program_length):

    text_records = []

    obj_codes = []

    for entry in intermediate:

        loc, label, opcode, operand = entry

        # Machine Instruction
        if opcode in OPCODES:

            addr = symtab.get(operand, 0)

            obj_code = (
                OPCODES[opcode] +
                format(addr, '04X')
            )

            obj_codes.append(
                (loc, obj_code)
            )

        # BYTE Directive
        elif opcode == "BYTE":

            # Character Constant
            if operand.startswith("C"):

                value = operand[2:-1]

                obj_code = ascii_to_hex(value)

            # Hex Constant
            elif operand.startswith("X"):

                obj_code = operand[2:-1]

            obj_codes.append(
                (loc, obj_code)
            )

    # ======================================================
    # CREATE TEXT RECORD
    # ======================================================

    start_addr = obj_codes[0][0]

    text = ""

    for loc, code in obj_codes:

        text += code

    length = len(text) // 2

    return start_addr, text, length


# ==========================================================
# GENERATE OBJECT PROGRAM RECORDS
# ==========================================================

def generate_records(program,
                     symtab,
                     program_length,
                     start_addr,
                     text,
                     text_len):

    prog_name = program[0][0]

    # Header Record
    H = (
        f"H^{prog_name}^"
        f"{format(start_addr, '06X')}^"
        f"{format(program_length, '06X')}"
    )

    # Text Record
    T = (
        f"T^{format(start_addr, '06X')}^"
        f"{format(text_len, '02X')}^"
        f"{text}"
    )

    # End Record
    E = f"E^{format(start_addr, '06X')}"

    return H, T, E


# ==========================================================
# INPUT PROGRAM
# ==========================================================

program = [

    ("PG2", "START", "1000"),

    ("-", "JMP", "ADD1"),

    ("-", "JMP", "ADD2"),

    ("ADD1", "LDA", "#1020"),

    ("-", "STA", "#3040"),

    ("ADD2", "LDA", "#1004"),

    ("DATA1", "BYTE", "C'ABC'"),

    ("DATA2", "EQU", "10"),

    ("-", "END", "-")
]


# ==========================================================
# RUN PASS 1
# ==========================================================

symtab, intermediate, program_length = pass1(program)


# ==========================================================
# RUN PASS 2
# ==========================================================

start_addr, text, text_len = pass2(
    intermediate,
    symtab,
    program_length
)


# ==========================================================
# GENERATE OBJECT PROGRAM RECORDS
# ==========================================================

H, T, E = generate_records(
    program,
    symtab,
    program_length,
    start_addr,
    text,
    text_len
)


# ==========================================================
# DISPLAY OUTPUT
# ==========================================================

print("==================================================")
print("                SYMBOL TABLE")
print("==================================================")

for symbol, address in symtab.items():

    print(f"{symbol:<10} : {format(address, '04X')}")


print("\n==================================================")
print("               OBJECT PROGRAM")
print("==================================================")

print("\nHeader Record:")
print(H)

print("\nText Record:")
print(T)

print("\nEnd Record:")
print(E)

print("\n==================================================")