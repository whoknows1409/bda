int main()
{
    auto short a = 1;

    const float b = 2.5;

    unsigned long c;

    static double d;

    extern char e;

    volatile signed int f;

    if (a < 1 && b >= 2.0 || !c)
    {
        f = a + 10 * 2 / 1 % 3;

        a++;
    }

    else if (d == 4.0 != 0)
    {
        goto end;
    }

    for (register int i = 0; i <= 5; i--)
        continue;

    while (sizeof(f) > 0)
        break;

    switch (a)
    {
        case 1:
            return 0;

        default:
            do
            {
            }
            while(0);
    }

    struct S {};

    union U {};

    enum E {X};

    typedef void V;

end:

    return a;
}