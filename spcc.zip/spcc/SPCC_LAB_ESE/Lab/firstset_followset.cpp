#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <set>

using namespace std;

// Structure for Grammar Rule
struct Rule
{
    string nt;
    vector<string> rhs;
};

vector<Rule> grammar;

map<string, set<string>> firstSet;
map<string, set<string>> followSet;

// Check whether symbol is Non-Terminal
bool isNonTerminal(string s)
{
    return !s.empty() && isupper(s[0]);
}

// Get first grammar symbol
string getSymbol(string s)
{
    if (s.empty())
        return "";

    string sym = string(1, s[0]);

    int i = 1;

    while (i < s.length() && s[i] == '\'')
    {
        sym += s[i];
        i++;
    }

    return sym;
}

// Remove Left Recursion
void removeLeftRecursion()
{
    vector<Rule> newGrammar;

    for (int i = 0; i < grammar.size(); i++)
    {
        string A = grammar[i].nt;

        // Replace previous non-terminals
        for (int j = 0; j < i; j++)
        {
            string B = grammar[j].nt;

            vector<string> updated;

            for (string prod : grammar[i].rhs)
            {
                string first = getSymbol(prod);

                if (first == B)
                {
                    string rest = prod.substr(B.length());

                    for (string bProd : grammar[j].rhs)
                    {
                        string prefix = (bProd == "#") ? "" : bProd;

                        updated.push_back(prefix + rest);
                    }
                }
                else
                {
                    updated.push_back(prod);
                }
            }

            grammar[i].rhs = updated;
        }

        // Check Immediate Left Recursion
        vector<string> alpha, beta;

        for (string prod : grammar[i].rhs)
        {
            string first = getSymbol(prod);

            if (first == A)
            {
                alpha.push_back(prod.substr(A.length()));
            }
            else
            {
                beta.push_back(prod);
            }
        }

        // Left Recursion Exists
        if (!alpha.empty())
        {
            string Aprime = A + "'";

            Rule ruleA, ruleAprime;

            ruleA.nt = A;
            ruleAprime.nt = Aprime;

            // A -> beta A'
            for (string b : beta)
            {
                string prefix = (b == "#") ? "" : b;

                ruleA.rhs.push_back(prefix + Aprime);
            }

            // A' -> alpha A' | #
            for (string a : alpha)
            {
                string prefix = (a == "#") ? "" : a;

                ruleAprime.rhs.push_back(prefix + Aprime);
            }

            ruleAprime.rhs.push_back("#");

            newGrammar.push_back(ruleA);
            newGrammar.push_back(ruleAprime);
        }
        else
        {
            newGrammar.push_back(grammar[i]);
        }
    }

    grammar = newGrammar;
}

// Compute FIRST Sets
void computeFirst()
{
    bool changed = true;

    while (changed)
    {
        changed = false;

        for (Rule r : grammar)
        {
            int before = firstSet[r.nt].size();

            for (string prod : r.rhs)
            {
                string sym = getSymbol(prod);

                // Terminal
                if (!isNonTerminal(sym))
                {
                    firstSet[r.nt].insert(sym);
                }

                // Non-Terminal
                else
                {
                    for (string f : firstSet[sym])
                    {
                        firstSet[r.nt].insert(f);
                    }
                }
            }

            if (firstSet[r.nt].size() > before)
            {
                changed = true;
            }
        }
    }
}

// Compute FOLLOW Sets
void computeFollow()
{
    // Start Symbol gets $
    if (!grammar.empty())
    {
        followSet[grammar[0].nt].insert("$");
    }

    bool changed = true;

    while (changed)
    {
        changed = false;

        for (Rule r : grammar)
        {
            for (string prod : r.rhs)
            {
                int pos = 0;

                while (pos < prod.length())
                {
                    string sym = getSymbol(prod.substr(pos));

                    int nextPos = pos + sym.length();

                    if (isNonTerminal(sym))
                    {
                        int before = followSet[sym].size();

                        // Symbol exists after current symbol
                        if (nextPos < prod.length())
                        {
                            string nextSym = getSymbol(prod.substr(nextPos));

                            // Terminal
                            if (!isNonTerminal(nextSym))
                            {
                                followSet[sym].insert(nextSym);
                            }

                            // Non-Terminal
                            else
                            {
                                bool hasEpsilon = false;

                                for (string f : firstSet[nextSym])
                                {
                                    if (f == "#")
                                    {
                                        hasEpsilon = true;
                                    }
                                    else
                                    {
                                        followSet[sym].insert(f);
                                    }
                                }

                                if (hasEpsilon)
                                {
                                    for (string f : followSet[r.nt])
                                    {
                                        followSet[sym].insert(f);
                                    }
                                }
                            }
                        }

                        // Symbol at end
                        else
                        {
                            for (string f : followSet[r.nt])
                            {
                                followSet[sym].insert(f);
                            }
                        }

                        if (followSet[sym].size() > before)
                        {
                            changed = true;
                        }
                    }

                    pos = nextPos;
                }
            }
        }
    }
}

// Print Set Properly
string printSet(set<string> s)
{
    if (s.empty())
    {
        return "{ }";
    }

    string res = "{ ";

    for (auto it = s.begin(); it != s.end(); ++it)
    {
        res += *it;

        if (next(it) != s.end())
        {
            res += ", ";
        }
    }

    res += " }";

    return res;
}

// Main Function
int main()
{
    int n;

    cout << "Enter number of production rules: ";
    cin >> n;

    cout << "\nEnter rules in format A->B|c|#\n";
    cout << "(Use # for epsilon and | for alternatives)\n\n";

    // Input Grammar
    for (int i = 0; i < n; i++)
    {
        string input;

        cin >> input;

        Rule r;

        int arrow = input.find("->");

        r.nt = input.substr(0, arrow);

        string rhs = input.substr(arrow + 2);

        int pipe;

        while ((pipe = rhs.find('|')) != string::npos)
        {
            r.rhs.push_back(rhs.substr(0, pipe));

            rhs = rhs.substr(pipe + 1);
        }

        r.rhs.push_back(rhs);

        grammar.push_back(r);
    }

    // Remove Left Recursion
    removeLeftRecursion();

    // Compute FIRST and FOLLOW
    computeFirst();

    computeFollow();

    // Print Grammar
    cout << "\n========== Grammar after Removing Left Recursion ==========\n";

    for (Rule r : grammar)
    {
        cout << r.nt << " -> ";

        for (int i = 0; i < r.rhs.size(); i++)
        {
            cout << (r.rhs[i] == "" ? "#" : r.rhs[i]);

            if (i < r.rhs.size() - 1)
            {
                cout << " | ";
            }
        }

        cout << endl;
    }

    // Print FIRST and FOLLOW Table
    cout << "\n================ FIRST and FOLLOW Sets ================\n\n";

    cout << "NT\tFIRST\t\t\tFOLLOW\n";

    cout << "---------------------------------------------------------------\n";

    for (Rule r : grammar)
    {
        string nt = r.nt;

        string first = printSet(firstSet[r.nt]);

        string follow = printSet(followSet[r.nt]);

        cout << nt << "\t";

        cout << first;

        if (first.length() < 24)
        {
            cout << "\t\t";
        }
        else
        {
            cout << "\t";
        }

        cout << follow << endl;
    }

    return 0;
}