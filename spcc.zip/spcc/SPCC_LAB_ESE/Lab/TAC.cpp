#include <iostream>
#include <stack>
#include <string>
#include <vector>
#include <sstream>
#include <iomanip>

using namespace std;

/*
==========================================================
        INTERMEDIATE CODE GENERATION PROGRAM
==========================================================

This program generates:

1. Quadruple Table
2. Triple Table
3. Indirect Triple Table

from a given Postfix Expression.

----------------------------------------------------------
Example Input:

a b + c d - *

----------------------------------------------------------
Example Operations:

t1 = a + b
t2 = c - d
t3 = t1 * t2

==========================================================
*/

/* Structure for Quadruple Representation */
struct Quadruple
{
    string op;
    string arg1;
    string arg2;
    string result;
};

/* Structure for Triple Representation */
struct Triple
{
    string op;
    string arg1;
    string arg2;
};

/* Function to check operators */
bool isOperator(const string& s)
{
    return (s == "+" ||
            s == "-" ||
            s == "*" ||
            s == "/" ||
            s == "=" ||
            s == "^");
}

/* Main Function */
int main()
{
    string input;

    cout << "==================================================\n";
    cout << "     Intermediate Code Generation Program\n";
    cout << "==================================================\n";

    cout << "\nEnter a Postfix Expression:\n";

    getline(cin, input);

    /* Stack for expression evaluation */
    stack<string> st;

    /* Tables */
    vector<Quadruple> quadTable;

    vector<Triple> tripleTable;

    vector<int> indirectTable;

    /* Temporary variable counter */
    int cnt = 1;

    /* Read expression token by token */
    stringstream ss(input);

    string token;

    while (ss >> token)
    {
        /* Operand */
        if (!isOperator(token))
        {
            st.push(token);
        }

        /* Operator */
        else
        {
            /* Invalid Expression Check */
            if (st.size() < 2)
            {
                cout << "\nInvalid Expression near operator: "
                     << token << endl;

                return 1;
            }

            /* Pop operands */
            string op2 = st.top();
            st.pop();

            string op1 = st.top();
            st.pop();

            /* ======================================
                    QUADRUPLE GENERATION
               ====================================== */

            Quadruple q;

            q.op = token;

            q.arg1 = op1;

            q.arg2 = op2;

            q.result = "T" + to_string(cnt++);

            quadTable.push_back(q);

            /* ======================================
                    TRIPLE GENERATION
               ====================================== */

            Triple t;

            t.op = token;

            t.arg1 = op1;

            t.arg2 = op2;

            tripleTable.push_back(t);

            /* Push reference for future operations */
            string ref = "(" +
                         to_string(tripleTable.size() - 1) +
                         ")";

            st.push(ref);

            /* Indirect Triple Pointer */
            indirectTable.push_back(tripleTable.size() - 1);
        }
    }

    /* ======================================
                DISPLAY OUTPUT
       ====================================== */

    cout << "\n==================================================\n";
    cout << "Postfix Expression: " << input << endl;
    cout << "==================================================\n";

    /* ======================================
                QUADRUPLE TABLE
       ====================================== */

    cout << "\nQUADRUPLE TABLE\n";

    cout << "--------------------------------------------------\n";

    cout << left
         << setw(10) << "Op"
         << setw(10) << "Arg1"
         << setw(10) << "Arg2"
         << setw(10) << "Result"
         << endl;

    cout << "--------------------------------------------------\n";

    for (const auto& row : quadTable)
    {
        cout << left
             << setw(10) << row.op
             << setw(10) << row.arg1
             << setw(10) << row.arg2
             << setw(10) << row.result
             << endl;
    }

    /* ======================================
                    TRIPLE TABLE
       ====================================== */

    cout << "\nTRIPLE TABLE\n";

    cout << "--------------------------------------------------\n";

    cout << left
         << setw(10) << "Index"
         << setw(10) << "Op"
         << setw(10) << "Arg1"
         << setw(10) << "Arg2"
         << endl;

    cout << "--------------------------------------------------\n";

    for (int i = 0; i < tripleTable.size(); i++)
    {
        cout << left
             << setw(10) << ("(" + to_string(i) + ")")
             << setw(10) << tripleTable[i].op
             << setw(10) << tripleTable[i].arg1
             << setw(10) << tripleTable[i].arg2
             << endl;
    }

    /* ======================================
                INDIRECT TRIPLE TABLE
       ====================================== */

    cout << "\nINDIRECT TRIPLE TABLE\n";

    cout << "--------------------------------------------------\n";

    cout << left
         << setw(15) << "Pointer"
         << setw(15) << "References"
         << endl;

    cout << "--------------------------------------------------\n";

    for (int i = 0; i < indirectTable.size(); i++)
    {
        cout << left
             << setw(15) << i
             << "(" << indirectTable[i] << ")"
             << endl;
    }

    cout << "\n==================================================\n";

    return 0;
}