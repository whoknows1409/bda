#include <iostream>
#include <map>
using namespace std;

int main() {

    int n;
    
    // Input number of symbols
    cout << "Enter number of symbols: ";
    cin >> n;

    string symbol;
    int value;

    // Symbol Table
    map<string, int> SYMTAB;

    // Taking symbol table input
    cout << "\nEnter Symbol Name and Value:\n";

    for(int i = 0; i < n; i++) {
        cin >> symbol >> value;
        SYMTAB[symbol] = value;
    }

    // Display Symbol Table
    cout << "\nSYMBOL TABLE\n";
    cout << "-------------------\n";
    cout << "Symbol\tValue\n";

    for(auto x : SYMTAB) {
        cout << x.first << "\t" << x.second << endl;
    }

    // Header Record
    string programName;
    int startAddress, programLength;

    cout << "\nEnter Program Name: ";
    cin >> programName;

    cout << "Enter Start Address: ";
    cin >> startAddress;

    cout << "Enter Program Length: ";
    cin >> programLength;

    // Generate H Record
    cout << "\nH RECORD\n";
    cout << "H^" << programName
         << "^" << startAddress
         << "^" << programLength << endl;

    // End Record
    cout << "\nE RECORD\n";
    cout << "E^" << startAddress << endl;

    return 0;
}