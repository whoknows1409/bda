#include <iostream>
#include <sstream>
#include <map>
using namespace std;

int main() {

    string line, word;

    // BLOCK TABLE
    map<string, int> BLOCKTAB;

    int blockNumber = 0;
    int n;

    // Number of lines in ASM program
    cout << "Enter number of lines: ";
    cin >> n;

    cin.ignore();

    cout << "\nEnter ASM Program:\n";

    for(int i = 0; i < n; i++) {

        getline(cin, line);

        stringstream ss(line);

        ss >> word;

        // Check USE directive
        if(word == "USE") {

            string blockName;
            ss >> blockName;

            // If block not already present
            if(BLOCKTAB.find(blockName) == BLOCKTAB.end()) {

                BLOCKTAB[blockName] = blockNumber;
                blockNumber++;
            }
        }
    }

    // Display Block Table
    cout << "\nBLOCK TABLE\n";
    cout << "----------------------\n";
    cout << "Block Name\tBlock No\n";

    for(auto x : BLOCKTAB) {

        cout << x.first << "\t\t" << x.second << endl;
    }

    return 0;
}