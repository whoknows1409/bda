#include <iostream>
#include <sstream>
#include <vector>
using namespace std;

int main() {

    string line;

    vector<string> DEFTAB;
    vector<string> NAMETAB;

    bool macroFound = false;

    int n;

    // Number of lines
    cout << "Enter number of lines: ";
    cin >> n;

    cin.ignore();

    cout << "\nEnter ASM Program:\n";

    for(int i = 0; i < n; i++) {

        getline(cin, line);

        stringstream ss(line);

        string word;
        ss >> word;

        // Check MACRO start
        if(word == "MACRO") {

            macroFound = true;

            // Read next line (Macro Name)
            getline(cin, line);

            DEFTAB.push_back(line);

            stringstream s(line);

            string macroName;
            s >> macroName;

            NAMETAB.push_back(macroName);

            i++;

            continue;
        }

        // Store Macro Body
        if(macroFound) {

            DEFTAB.push_back(line);

            // Check MEND
            if(line == "MEND") {

                macroFound = false;
            }
        }
    }

    // Display NAMETAB
    cout << "\nNAMETAB\n";
    cout << "----------------\n";

    for(int i = 0; i < NAMETAB.size(); i++) {

        cout << NAMETAB[i] << endl;
    }

    // Display DEFTAB
    cout << "\nDEFTAB\n";
    cout << "----------------\n";

    for(int i = 0; i < DEFTAB.size(); i++) {

        cout << DEFTAB[i] << endl;
    }

    return 0;
}